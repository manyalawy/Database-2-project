import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Vector;
import java.util.Properties;

public class Pages implements Serializable{

	Vector<Tuples> tuples;
	int rowsCount;
	Properties dbproperties;
	String fileName;
	String location;
	String path;
	int indexOfPage;
	private Properties dbProperties;
	int clusteringKeyIndex;
	
	
	public Pages(String fileName, Properties dbproperties, int indexOfPage, int clusteringKey ) {
		this.path=fileName+"-"+"page"+indexOfPage+".ser";
		this.rowsCount = 0;
		this.tuples = new Vector();
		this.dbproperties= dbproperties;
		writePage(path, this);
		
	
	}
	

	public void writePage(String path, Pages p){

		
		try {
			FileOutputStream fileOut =
					new FileOutputStream(path);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(p);
			out.close();
			fileOut.close();

		} catch (IOException i) {
			i.printStackTrace();
		}

	}	
		
	public Pages readPage(String path,Pages page) throws IOException, ClassNotFoundException{
		FileInputStream fileIn = new FileInputStream(path);
		ObjectInputStream in = new ObjectInputStream(fileIn);
		Pages p = (Pages) in.readObject();
		in.close();
		fileIn.close();
		
		if(page!=null){
		page.tuples=p.tuples;
		}
		return p;
	}
		
	
}

