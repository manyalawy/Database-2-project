
import java.awt.Dimension;
import java.awt.Polygon;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;

public class Table {
	String tableName;
	transient Vector <Pages> pages;
	Vector <String> colName;
	Vector <String> colTypes;
	String  clusteringKey;
	int clusteringKeyIndex;
	String clusteringKeyType;
	Properties dbProperties;
	
	
	
	
	public Table (String tableName, String clusteringKey,  Hashtable<String,String> htblColNameType, Properties dbProperties) throws IOException {
			
			this.dbProperties = dbProperties;
			this.tableName=tableName;
			Set <String> keys= htblColNameType.keySet();
			this.clusteringKey = clusteringKey;
			this.colName= new Vector();
			this.colTypes=new Vector();
			FileWriter metadata = new FileWriter("metadata.csv",true);
			colName.add("Touch date");
			colTypes.add("java.util.Date");
			for (String key : keys)
			{
				colName.add(key);	
				colTypes.add(htblColNameType.get(key));
			}
			
			this.clusteringKeyIndex=colName.indexOf(clusteringKey);
			this.clusteringKeyType=htblColNameType.get(clusteringKey);
			this.pages = new Vector();
			
			
			
			
			
			
	}




	public void insertIntoTable2(Hashtable<String, Object> htblColNameValue) throws DBAppException, ClassNotFoundException, IOException {
		Vector <String>tableTypes = this.getTypes();
		if(htblColNameValue.size()==tableTypes.size()-1){
			int i=1;
			boolean flag = true;
			for (String key : htblColNameValue.keySet()) {
				if(!(key.equals(colName.get(i)))){
					flag = false;
				}
				i+=1;
			}
			i = 1;
			if(flag = false) {
				throw new DBAppException("Incorrect column name/order");
			}
			else {
				for (String key : htblColNameValue.keySet()){
					switch(htblColNameValue.get(key).getClass().toString()){
					case "class java.lang.Integer": 
						if(!(tableTypes.get(i).equals("java.lang.Integer")))
							throw new DBAppException( key+". Should be " +colTypes.get(i));
						break;
					case "class java.lang.String":
						if(!(tableTypes.get(i).equals("java.lang.String")))
							throw new DBAppException( key+". Should be " +colTypes.get(i));
						break;
					case "class java.lang.double":
						if(!(tableTypes.get(i).equals("java.lang.double")))
							throw new DBAppException( key +". Should be " +colTypes.get(i) );
						break;
					case "class java.lang.Boolean":
						if(!(tableTypes.get(i).equals("java.lang.Boolean")))
							throw new DBAppException( key +". Should be " +colTypes.get(i) );
						break;
					case "class java.util.Date":
						if(!(tableTypes.get(i).equals("java.util.Date")))
							throw new DBAppException(key +". Should be " +colTypes.get(i) );
						break;
					case "class java.awt.Polygon":
						if(!(tableTypes.get(i).equals("java.awt.Polygon")))
							throw new DBAppException( key +". Should be of type " +colTypes.get(i) );	
				
					default: break;
					}
					i++;

				}
			}
			
			
			insertIntoTable3(htblColNameValue);
			
		}
		else {
			throw new DBAppException("Incorrect number of columns");
		}
			
			
		
		
				
		}
	
	public void insertIntoTable3(Hashtable<String, Object> htblColNameValue) throws ClassNotFoundException, IOException {
		Object l = htblColNameValue.get(clusteringKey);
		String insClustKey = l.toString();
		boolean flag = false;
		int pageIndex = 0;
		int tupleIndex = 0;
		if(this.pages.size() == 0) {
			Pages x = new Pages(this.tableName,this.dbProperties, 0, this.clusteringKeyIndex );
			Tuples y = this.convertToTuple(htblColNameValue);
			x.rowsCount= x.rowsCount +1;
			x.tuples.add(y);
			this.pages.add(x);
			x.writePage(x.path, x);
		}
		else {
			for (int i = 0; i < this.pages.size(); i++) {
				for (int j = 0; j < pages.get(i).tuples.size(); j++) {
					if(insClustKey.compareTo(pages.get(i).tuples.get(j).row.get(clusteringKeyIndex).toString())>0) {
						j++;
					}
					else {
						flag =true;
						tupleIndex = j;
						break;
					}
				}
				if (flag = true) {
					pageIndex = i;							
					break;
				}		
			}
			
			if(pages.lastElement().rowsCount==Integer.parseInt(dbProperties.getProperty("MaximumRowsCountinPage"))){
				Pages x = new Pages(this.tableName,dbProperties,(pages.indexOf(pages.lastElement()) + 1), clusteringKeyIndex);
				pages.add(x);
				x.writePage(x.path, x);
				
			}
			if(this.pages.get(pageIndex).rowsCount==Integer.parseInt(dbProperties.getProperty("MaximumRowsCountinPage"))) {
				 flag = false;
				 int numberOfShifts = 0;
				 for (int i = pageIndex; i< pages.size()-pageIndex +1; i++) {
					
					 if(this.pages.get(i).rowsCount==Integer.parseInt(dbProperties.getProperty("MaximumRowsCountinPage"))) {
						 numberOfShifts++;
					 }
					 else {
						 break;
					 }
				}
					int i = 0;
					int index = pageIndex;
					while(numberOfShifts != 0 ) {
						
						this.pages.get(index+1).tuples.add(0, this.pages.get(index).tuples.lastElement());
						this.pages.get(index).rowsCount--;
						numberOfShifts--;
						index++;
					}
				Tuples x = this.convertToTuple(htblColNameValue);
				Pages p =this.pages.get(pageIndex).readPage(this.pages.get(pageIndex).path, this.pages.get(pageIndex));
				p.tuples.add(tupleIndex, x);			
				p.rowsCount++;
				p.writePage(p.path, p);
			}
			else {
				Tuples x = this.convertToTuple(htblColNameValue);
			Pages p =this.pages.get(pageIndex).readPage(this.pages.get(pageIndex).path, this.pages.get(pageIndex));
				p.tuples.add(tupleIndex, x);			
				p.rowsCount++;
				p.writePage(p.path, p);
				
			}
		
		}

		
	}




	public Vector getTypes() {
		String csvFile = "metadata.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        Vector tableTypes = new Vector<>();

        try {

            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] rows = line.split(cvsSplitBy);
             
                tableTypes.add(rows[2]);
                

            }
            tableTypes.remove(0);
            

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

		
		
		return tableTypes;
		
	}
	

	
	
	public void updateTableHelper (String strClusteringKey, Hashtable<String,Object> htblColNameValue ) throws DBAppException, ClassNotFoundException, IOException{
		Vector <String>tableTypes = this.getTypes();
		if(htblColNameValue.size()==tableTypes.size()-1){
			int i=1;
			boolean flag = true;
			for (String key : htblColNameValue.keySet()) {
				if(!(key.equals(colName.get(i)))){
					flag = false;
				}
				i+=1;
			}
			i = 1;
			if(flag = false) {
				throw new DBAppException("Incorrect column name/order");
			}
			else {
				for (String key : htblColNameValue.keySet()){
					switch(htblColNameValue.get(key).getClass().toString()){
					case "class java.lang.Integer": 
						if(!(tableTypes.get(i).equals("java.lang.Integer")))
							throw new DBAppException( key+". Should be " +colTypes.get(i));
						break;
					case "class java.lang.String":
						if(!(tableTypes.get(i).equals("java.lang.String")))
							throw new DBAppException( key+". Should be " +colTypes.get(i));
						break;
					case "class java.lang.double":
						if(!(tableTypes.get(i).equals("java.lang.double")))
							throw new DBAppException( key +". Should be " +colTypes.get(i) );
						break;
					case "class java.lang.Boolean":
						if(!(tableTypes.get(i).equals("java.lang.Boolean")))
							throw new DBAppException( key +". Should be " +colTypes.get(i) );
						break;
					case "class java.util.Date":
						if(!(tableTypes.get(i).equals("java.util.Date")))
							throw new DBAppException(key +". Should be " +colTypes.get(i) );
						break;
					case "class java.awt.Polygon":
						if(!(tableTypes.get(i).equals("java.awt.Polygon")))
							throw new DBAppException( key +". Should be of type " +colTypes.get(i) );	
				
					default: break;
					}
					i++;

				}
			
		}
			else {
				throw new DBAppException("Incorrect number of columns");
			}
		
		

	//for (int i=0; i<pages.size();i++){
//		Pages x= pages.get(i).readPage(pages.get(i).path, pages.get(i));
//			for (int j=0; j<x.tuples.size();j++){
//				
//				if(this.clusteringKey.equals(strClusteringKey)){
//					int k=0;
//					int index;
//					String keyy;
//					for (String key : htblColNameValue.keySet()){
//						if(colName.get(k).compareTo(htblColNameValue.get(key).toString())==0){
//							index=colName.indexOf(key);
//							keyy=key.toString();
//							x.tuples.get(j).row.set(index, keyy);
//							k++;
//						}
//						else{
//							k++;
//						}
//					}
//				}
//				pages.get(i).writePage(pages.get(i).path,pages.get(i));
//				break;
//			}
	//}
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		System.out.println(df.format(dateobj));
		
		for (int i=0; i<pages.size();i++){
			Pages x= pages.get(i).readPage(pages.get(i).path, pages.get(i));
				for (int j=0; j<x.tuples.size();j++){
					
					if(this.clusteringKey.equals(strClusteringKey)){
						for(int k=0;k<colName.size();k++){
							
							int index;
							if(colName.get(k).compareTo(htblColNameValue.keySet().toString())==0){
								index=colName.indexOf(i);
								x.tuples.get(j).row.set(index, htblColNameValue.values().toString());
								
								for(int l=0;l<colName.size();l++){
								boolean flag;	
								if(colName.get(k).equals("Touch Date")){
									int dateIndx =colName.indexOf(i);
									x.tuples.get(j).row.set(dateIndx, df.toString());
								}
									}
								break;
							}
			                                               			}
						pages.get(i).writePage(pages.get(i).path,pages.get(i));
					}
					
					else {
						throw new DBAppException("This key does not exist");
					}}
					
					
				}
		
		
		
		
		
	}


	}
	


	
	
	
	

	
	

