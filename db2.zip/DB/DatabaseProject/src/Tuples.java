import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Hashtable;
import java.util.Set;
import java.util.Vector;

public class Tuples implements Serializable {
	Vector <String> row;
	
	public Tuples (Vector <String> row){
		this.row=row;
	}
	
	public Tuples convertToTuple(Hashtable<String, Object> htblColNameValue) {
		//
		Set<String> keys = htblColNameValue.keySet();
		Vector row = new Vector<>();
		 Date date= new Date();
         //getTime() returns current time in milliseconds
	 long time = date.getTime();
         //Passed the milliseconds to constructor of Timestamp class 
	 Timestamp ts = new Timestamp(time);
	 row.add(ts);
		for (String key : keys) {
			
			Object value = htblColNameValue.get(key);
			row.add(value);
		}
		Tuples x = new Tuples(row);
		return x;
		
	}
	
}
