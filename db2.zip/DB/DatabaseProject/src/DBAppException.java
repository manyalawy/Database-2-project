
public class DBAppException extends Exception{

	public DBAppException(){
		super();
	}
	
	public DBAppException(String m){
		super(m);
	}
}
