import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Hashtable;

public class Test {

	
	public static void main(String[]args) throws IOException, DBAppException {
		

//		FileWriter metadata = new FileWriter("metadata.csv",true);
//
//		metadata.append("Table name");
//		metadata.append(',');
//		metadata.append("Column name");
//		metadata.append(',');
//		metadata.append("Column type");
//		metadata.append(',');
//		metadata.append(" ClusteringKey");
//		metadata.append(',');
//		metadata.append("Indexed");
//		metadata.append('\n');
//		
//		metadata.flush();
//		metadata.close();
		
		
		String strTableName = "Student";
	    DBApp dbApp = new DBApp();
	    Hashtable htblColNameType = new Hashtable();
	    htblColNameType.put("id", "java.lang.Integer");
	    htblColNameType.put("name", "java.lang.String");
	    htblColNameType.put("gpa", "java.lang.double");
	    dbApp.createTable(strTableName, "id", htblColNameType);
//		for(int i=0; i<colTypes.size();i++){
//			metadata.append(tableName);
//			metadata.append(',');
//			metadata.append(colName.get(i+1));
//			metadata.append(',');
//			metadata.append(colTypes.get(i));
//			metadata.append(',');
//			if(colName.get(i+1).equals(clusteringKey))
//				metadata.append("true");
//			else
//				metadata.append("false");
//			metadata.append(',');
//			metadata.append("false");
//			metadata.append('\n');
//		}
//		metadata.flush();
//		metadata.close();
//	}
}
}