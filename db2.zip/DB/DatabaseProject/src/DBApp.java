import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;
// manyal's version
public class DBApp {

	Vector<Table> tables;
	Properties dbProperties;
	
	public DBApp() throws IOException {
		FileWriter metadata = new FileWriter("metadata.csv",true);
		metadata.append("Table name");
		metadata.append(',');
		metadata.append("Column name");
		metadata.append(',');
		metadata.append("Column type");
		metadata.append(',');
		metadata.append("Key");
		metadata.append(',');
		metadata.append("Indexed");
		metadata.append('\n');
		metadata.flush();
		metadata.close();
		tables = new Vector<Table>();
		dbProperties = new Properties();
		dbProperties.setProperty("MaximumRowsCountinPage", "200");
		dbProperties.setProperty("NodeSize", "15");
		FileOutputStream out = new FileOutputStream("DBApp.properties");
		dbProperties.store(out, null);
		out.close();
	}
	
	public void init() throws IOException {
		
	}
	
	public void createTable(String strTableName, String strClusteringKeyColumn, Hashtable<String,String> htblColNameType ) throws IOException, DBAppException {
	
            
        
		boolean flag = true;
		for (int i = 0; i < tables.size(); i++) {
			if (tables.get(i).tableName.equals(strTableName)) {
				
				flag = false;
			}

		}
		if(flag == true) {
			
			Table table = new Table(strTableName, strClusteringKeyColumn,
					htblColNameType, dbProperties);
			tables.add(table);
			Set <String> keys= htblColNameType.keySet();
			Vector<String> colName= table.colName;
			Vector <String>colTypes=table.colTypes;
			FileWriter metadata = new FileWriter("metadata.csv",true);

			for(int i=0; i<colTypes.size();i++){
				metadata.append(strTableName);
				metadata.append(',');
				metadata.append(colName.get(i));
				metadata.append(',');
				metadata.append(colTypes.get(i));
				metadata.append(',');
				if(colName.get(i).equals(strClusteringKeyColumn))
					metadata.append("true");
				else
					metadata.append("false");
				metadata.append(',');
				metadata.append("false");
				metadata.append('\n');
			}
			metadata.flush();
			metadata.close();
		}
		else {
			throw new DBAppException("The table name " + strTableName
					+ " already exists");
		}
			
	}
	
	
	public void deleteFromTable(String strTableName, Hashtable<String,Object> htblColNameValue) {
		
	}
	
	public void insertIntoTable(String strTableName, Hashtable<String,Object> htblColNameValue) throws DBAppException, ClassNotFoundException, IOException {
		for (int i = 0; i < tables.size(); i++) {
			if ((tables.get(i).tableName.equals(strTableName))) {
				tables.get(i).insertIntoTable2(htblColNameValue);
				break;
			}
			if (!(tables.get(i).tableName.equals(strTableName))
					&& i == tables.size() - 1) {
				throw new DBAppException("The table " + strTableName
						+ " does not exist");
			}
		}
	}
	
	
public void updateTable(String strTableName, String strClusteringKey, Hashtable<String,Object> htblColNameValue ) throws DBAppException, ClassNotFoundException, IOException{
		
		for( int i=0; i<tables.size();i++){
			if (! (tables.get(i).tableName.equals(strTableName))){
				throw new DBAppException("The table " + strTableName + " does not exist");
			}
			else {
				tables.get(i).updateTableHelper( strClusteringKey, htblColNameValue);
			}
		}
		
	}
	
	public static void main(String[] args) throws IOException, DBAppException {
				
		DBApp y = new DBApp();
		Hashtable x = new Hashtable<>();
		Hashtable z = new Hashtable<>();
		z.put("id",1);
		z.put("name", "wow");
		
		x.put("id", "java.lang.Integer");
		x.put("name", "java.lang.String");
		y.createTable("nwb", "id", x);
		y.insertIntoTable("nwb", z);
		int j = 0;
	
	for (int i = 0; i < 3; i++) {
		j++;
	}
	System.out.println(j);
		
		
		
		
	
	}
	
}
